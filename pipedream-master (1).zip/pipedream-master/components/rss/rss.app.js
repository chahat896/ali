module.exports = {
  type: 'app',
  app: 'rss',
}