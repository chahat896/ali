module.exports = {
  type: "app",
  app: "dev_to",
}