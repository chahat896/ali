module.exports = {
  type: "app",
  app: "twitter_developer_app",
}
