module.exports = [
  {
    label: "Open (Engagement Event)",
    value: "open"
  },
  {
    label: "Click (Engagement Event)",
    value: "click"
  },
  {
    label: "Spam Report (Engagement Event)",
    value: "spam_report"
  },
  {
    label: "Unsubscribe (Engagement Event)",
    value: "unsubscribe"
  },
  {
    label: "Group Unsubscribe (Engagement Event)",
    value: "group_unsubscribe"
  },
  {
    label: "Group Resubscribe (Engagement Event)",
    value: "group_resubscribe"
  }
];
