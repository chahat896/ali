module.exports = [
  {
    label: "Processed (Delivery Event)",
    value: "processed"
  },
  {
    label: "Dropped (Delivery Event)",
    value: "dropped"
  },
  {
    label: "Delivered (Delivery Event)",
    value: "delivered"
  },
  {
    label: "Deferred (Delivery Event)",
    value: "deferred"
  },
  {
    label: "Bounce (Delivery Event)",
    value: "bounce"
  }
];
