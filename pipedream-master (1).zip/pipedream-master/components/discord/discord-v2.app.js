module.exports = {
  type: "app",
  app: "discord",
  propDefinitions: {
  },
  methods: {
  },
}
