module.exports = {
  type: "app",
  app: "zoom_admin",
};