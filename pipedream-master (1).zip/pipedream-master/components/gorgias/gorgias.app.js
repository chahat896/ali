// Gorgias app file
module.exports = {
  type: "app",
  app: "gorgias",
}
