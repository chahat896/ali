module.exports = {
  type: "app",
  app: "hacker_news",
}