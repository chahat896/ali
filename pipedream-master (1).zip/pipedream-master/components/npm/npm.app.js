module.exports = {
  type: "app",
  app: "npm",
}