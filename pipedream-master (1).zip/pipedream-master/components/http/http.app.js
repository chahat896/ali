module.exports = {
  type: 'app',
  app: 'http',
}