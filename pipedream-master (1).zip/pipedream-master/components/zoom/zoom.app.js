module.exports = {
  type: "app",
  app: "zoom",
};