<template>
  <footer>
    <h2 id="still-have-questions">
      <a href="#still-have-questions" aria-hidden="true" class="header-anchor">#</a> Still have questions?
    </h2>
    <p>
      Please
      <a href="/support/" class>reach out</a> if this doc didn't answer your question. We're happy to help!
    </p>
  </footer>
</template>