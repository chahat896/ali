# Send an email to someone else

If you need to send an email to yourself, [see this guide](/workflows/examples/send-yourself-email/).

If you need to send an email to another person, you'll need to use an email service. Pipedream has [native integrations with many email services](/apps/all-apps/), so it's easy to send email from a workflow. In the video below, we'll show you how to send an email using [Sendgrid](https://sendgrid.com/)

<Footer />
