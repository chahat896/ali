# Trigger a workflow on events from another app

<Footer />
