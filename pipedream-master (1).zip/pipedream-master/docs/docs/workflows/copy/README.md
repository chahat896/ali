# Copying Workflows

When you find a public workflow that you want to use, you **Copy** it into your own account. You own the copy, and can run and modify that copy however you'd like.

When you find the workflow that you'd like to copy, click the big green **Copy** button near the top-right corner of the workflow.

If you're not signed into your Pipedream account, or haven't yet signed up, you'll be prompted to.

<Footer />
