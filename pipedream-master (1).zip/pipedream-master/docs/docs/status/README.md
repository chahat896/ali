# Service Status

Pipedream operates a status page at [https://status.pipedream.com](https://status.pipedream.com). That page displays the uptime history and current status of every Pipedream service.

When incidents occur, updates are published to the **#incidents** channel of [Pipedream's Slack Community](https://pipedream.com/community) and to the [@PipedreamStatus](https://twitter.com/PipedreamStatus) account on Twitter. On the status page itself, you can also subscribe to updates directly.

<Footer />
