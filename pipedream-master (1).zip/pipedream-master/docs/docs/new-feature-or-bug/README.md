---
prev: false
next: false
---

# New Features / Bugs

To request a new feature or app integration, or to report a new bug, please [see the instructions here](https://github.com/PipedreamHQ/pipedream#found-a-bug-have-a-feature-to-suggest).
