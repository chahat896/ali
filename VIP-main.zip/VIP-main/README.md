![PicsArt_11-29-08 29 05](https://user-images.githubusercontent.com/52023076/100546596-12718c00-3217-11eb-8cbd-d79f87ef63de.jpg)

# VIP_Install
```
apt update && apt upgrade 
apt install python2 -y
apt install git -y
git clone https://github.com/Tech-abm/VIP
cd VIP
python2 coding.py
```
# User and Pass
```
Username > Abm
Password > Abm
```
# Folow me 
<p align="center">
<a href="https://fb.com/Techabm"><img title="Facebook" src="https://img.shields.io/badge/Facebook-red?style=for-the-badge&logo=facebook"></a>
<a href="https://www.instagram.com/Techabm"><img title="Instagram" src="https://img.shields.io/badge/INSTAGRAM-purple?style=for-the-badge&logo=instagram"></a>
<a href="https://github.com/Tech-abm"><img title="Github" src="https://img.shields.io/badge/Github-TECH--ABM-blue?style=for-the-badge&logo=github"></a>
